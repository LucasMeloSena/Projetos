﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex04Pag35
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int matricula, numHoras, numExtras;
            double cargo, salarioBruto, salarioLiquido, adicionalHoras, INSS;

            matricula = int.Parse(txtMatricula.Text);
            cargo = matricula / 10000;
            Math.Round(cargo, 0);
            
            numHoras = int.Parse(txtNumHoras.Text);
            numExtras = int.Parse(txtNumExtras.Text);

            if (matricula > 10000 && matricula < 59999)
            {
                switch (cargo)
                {
                    case 1: salarioBruto = numHoras * 8; txtSalarioBruto.Text = "R$" + salarioBruto.ToString("0.00");
                            adicionalHoras = numExtras * 12; txtAdicional.Text = "R$" + adicionalHoras.ToString("0.00");
                            INSS = salarioBruto * 0.11; txtINSS.Text = "R$" + INSS.ToString("0.00");
                            salarioLiquido = salarioBruto + adicionalHoras - INSS; txtSalarioLiquido.Text = "R$" + salarioLiquido.ToString("0.00");
                            break;

                    case 2:
                        salarioBruto = numHoras * 10; txtSalarioBruto.Text = "R$" + salarioBruto.ToString("0.00");
                        adicionalHoras = numExtras * 15; txtAdicional.Text = "R$" + adicionalHoras.ToString("0.00");
                        INSS = salarioBruto * 0.11; txtINSS.Text = "R$" + INSS.ToString("0.00");
                        salarioLiquido = salarioBruto + adicionalHoras - INSS; txtSalarioLiquido.Text = "R$" + salarioLiquido.ToString("0.00");
                        break;

                    case 3:
                        salarioBruto = numHoras * 12; txtSalarioBruto.Text = "R$" + salarioBruto.ToString("0.00");
                        adicionalHoras = numExtras * 18; txtAdicional.Text = "R$" + adicionalHoras.ToString("0.00");
                        INSS = salarioBruto * 0.11; txtINSS.Text = "R$" + INSS.ToString("0.00");
                        salarioLiquido = salarioBruto + adicionalHoras - INSS; txtSalarioLiquido.Text = "R$" + salarioLiquido.ToString("0.00");
                        break;

                    case 4:
                        salarioBruto = numHoras * 15; txtSalarioBruto.Text = "R$" + salarioBruto.ToString("0.00");
                        adicionalHoras = numExtras * 22.5; txtAdicional.Text = "R$" + adicionalHoras.ToString("0.00");
                        INSS = salarioBruto * 0.11; txtINSS.Text = "R$" + INSS.ToString("0.00");
                        salarioLiquido = salarioBruto + adicionalHoras - INSS; txtSalarioLiquido.Text = "R$" + salarioLiquido.ToString("0.00");
                        break;

                    case 5:
                        salarioBruto = numHoras * 20; txtSalarioBruto.Text = "R$" + salarioBruto.ToString("0.00");
                        adicionalHoras = numExtras * 30; txtAdicional.Text = "R$" + adicionalHoras.ToString("0.00");
                        INSS = salarioBruto * 0.11; txtINSS.Text = "R$" + INSS.ToString("0.00");
                        salarioLiquido = salarioBruto + adicionalHoras - INSS; txtSalarioLiquido.Text = "R$" + salarioLiquido.ToString("0.00");
                        break;
                }
            } 
            
            else
            {
                MessageBox.Show("Matrícula inválida, Digite apenas 5 dígitos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtMatricula.Clear();
            txtNumHoras.Clear();
            txtNumExtras.Clear();
        }
    }
}
